// Copyright Epic Games, Inc. All Rights Reserved.

#include "Only_UpGameMode.h"

AOnly_UpGameMode::AOnly_UpGameMode()
{
	// stub
}
