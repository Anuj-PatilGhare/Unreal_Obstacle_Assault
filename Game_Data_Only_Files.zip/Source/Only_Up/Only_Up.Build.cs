// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class Only_Up : ModuleRules
{
	public Only_Up(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] {
			"Core",
			"CoreUObject",
			"Engine",
			"InputCore",
			"EnhancedInput",
			"AIModule",
			"StateTreeModule",
			"GameplayStateTreeModule",
			"UMG",
			"Slate"
		});

		PrivateDependencyModuleNames.AddRange(new string[] { });

		PublicIncludePaths.AddRange(new string[] {
			"Only_Up",
			"Only_Up/Variant_Platforming",
			"Only_Up/Variant_Platforming/Animation",
			"Only_Up/Variant_Combat",
			"Only_Up/Variant_Combat/AI",
			"Only_Up/Variant_Combat/Animation",
			"Only_Up/Variant_Combat/Gameplay",
			"Only_Up/Variant_Combat/Interfaces",
			"Only_Up/Variant_Combat/UI",
			"Only_Up/Variant_SideScrolling",
			"Only_Up/Variant_SideScrolling/AI",
			"Only_Up/Variant_SideScrolling/Gameplay",
			"Only_Up/Variant_SideScrolling/Interfaces",
			"Only_Up/Variant_SideScrolling/UI"
		});

		// Uncomment if you are using Slate UI
		// PrivateDependencyModuleNames.AddRange(new string[] { "Slate", "SlateCore" });

		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");

		// To include OnlineSubsystemSteam, add it to the plugins section in your uproject file with the Enabled attribute set to true
	}
}
