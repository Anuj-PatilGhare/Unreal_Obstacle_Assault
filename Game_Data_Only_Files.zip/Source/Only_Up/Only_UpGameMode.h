// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Only_UpGameMode.generated.h"

/**
 *  Simple GameMode for a third person game
 */
UCLASS(abstract)
class AOnly_UpGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
   
	/** Constructor */
	AOnly_UpGameMode();
};



