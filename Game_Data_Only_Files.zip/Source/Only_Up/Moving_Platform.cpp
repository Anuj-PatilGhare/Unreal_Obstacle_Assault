// Fill out your copyright notice in the Description page of Project Settings.


#include "Moving_Platform.h"

// Sets default values
AMoving_Platform::AMoving_Platform()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AMoving_Platform::BeginPlay()
{
	Super::BeginPlay();

	//FVector TestVector = FVector(54.2f,3.54f,7.6f);
	//TestVector.X = 54.65f;
	//UE_LOG(LogTemp,Display,TEXT("This is the value %f"), MainVector.X)
	//MainVector.X = 87.5f;
	//UE_LOG(LogTemp, Display, TEXT("The Updated Values is %f"), MainVector.X);

	//FVector TestVector = FVector(696.344185f, 1150.090753f, 410.000000f);
	//TestFunction();

	StartLocation = GetActorLocation();
	
}

// Called every frame
void AMoving_Platform::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//ActorNewLocation.Z = ActorNewLocation.Z + 1;
	//SetActorLocation(ActorNewLocation);

	MovePlatform(DeltaTime);  // Function Call
	RotatePlatform(DeltaTime); //Function Call 

}


void  AMoving_Platform::MovePlatform(float DeltaTime)
{

	DistanceMoved = GetDistanceMoved();

	if(DistanceMoved >= MoveDistance)
	{	
		//StartLocation = CurrentLocation;
		//float OverShoot = DistanceMoved - MoveDistance;  //OverShoot Problem :

		FVector MoveDirection = PlatformVelocity.GetSafeNormal();
		FVector NewStartLocation = StartLocation + MoveDirection * MoveDistance;
		SetActorLocation(NewStartLocation);
		StartLocation = NewStartLocation;

		PlatformVelocity = -PlatformVelocity;
	}
	else
	{
		FVector CurrentLocation = GetActorLocation(); // Getting Current Location of Actor :
		CurrentLocation = CurrentLocation + (PlatformVelocity * DeltaTime); // FVector Multipliaction :
		SetActorLocation(CurrentLocation); //Setting Location :

	}
}

void  AMoving_Platform::RotatePlatform(float Deltatime) {

	AddActorLocalRotation(RotationVelocity * Deltatime); // Platform Rotation with FRotator :
}

float AMoving_Platform::GetDistanceMoved()
{ 
	return FVector::Dist(StartLocation, GetActorLocation());
}