// Copyright Epic Games, Inc. All Rights Reserved.

#include "Only_Up.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Only_Up, "Only_Up" );

DEFINE_LOG_CATEGORY(LogOnly_Up)