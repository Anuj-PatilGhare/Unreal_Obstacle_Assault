// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Moving_Platform.generated.h"

UCLASS()
class ONLY_UP_API AMoving_Platform : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AMoving_Platform();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;


	void MovePlatform(float Deltatime);    // Moves Platform
	void RotatePlatform(float Deltatime); // Rotate Platform

	float GetDistanceMoved();


	UPROPERTY(EditAnywhere) 
	FVector PlatformVelocity = FVector(0.0f, 0.0f, 0.0f); // For Setting Instance Velocity :

	UPROPERTY(VisibleAnywhere)
	float DistanceMoved = 0.0f; // To see Moved Distance :

	UPROPERTY(EditAnywhere)
	float MoveDistance = 100.f; // Set Value for Move :

	UPROPERTY(EditAnywhere)
	FRotator RotationVelocity;

	FVector StartLocation; // FVector Declration :
	


	//UPROPERTY(EditAnywhere)
	//float MemberFloat = 40.8f;

	//UPROPERTY(VisibleAnywhere)
	//int NumberOfShots = 5;

	//UPROPERTY(EditAnywhere)
	//FVector ActorNewLocation = FVector();

};
